# crud-php-mvc-buku-kita
Project/CRUD kecil dengan judul Aplikasi Buku Kita menggunakan PHP 7 MVC
Selengkapnya silahkan kunjungi gilacoding.com
